"""
DATA FETCHER — Bot V11
Puxa dados reais do mercado via YFinance
Símbolos corretos e testados
"""

import yfinance as yf
import pandas as pd
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

# Símbolos corretos no YFinance
SYMBOLS = {
    'XAUUSD': 'GC=F',      # Ouro Futures
    'EURUSD': 'EURUSD=X',  # Euro/USD
    'USDJPY': 'USDJPY=X',  # USD/JPY
    'BTCUSD': 'BTC-USD',   # Bitcoin
    'DXY':    'DX-Y.NYB',  # Dólar Index
    'US10Y':  '^TNX',      # Yields 10Y
    'SP500':  '^GSPC',     # S&P 500
    'WTI':    'CL=F',      # Petróleo
}

TIMEFRAMES = {
    '1M':  ('7d',  '1m'),
    '5M':  ('7d',  '5m'),
    '15M': ('7d',  '15m'),
    '1H':  ('30d', '1h'),
    '2H':  ('60d', '2h'),
    '4H':  ('60d', '4h'),
    'D1':  ('3mo', '1d'),
}


def fetch_ohlcv(asset: str, timeframe: str) -> pd.DataFrame | None:
    """Puxa dados OHLCV de um ativo e timeframe."""
    symbol = SYMBOLS.get(asset)
    if not symbol:
        logger.error(f"Símbolo não encontrado para {asset}")
        return None

    period, interval = TIMEFRAMES.get(timeframe, ('3mo', '1d'))

    try:
        ticker = yf.Ticker(symbol)
        df = ticker.history(period=period, interval=interval)

        if df.empty:
            logger.warning(f"Sem dados para {asset} ({symbol}) TF={timeframe}")
            return None

        df = df[['Open', 'High', 'Low', 'Close', 'Volume']].copy()
        df.dropna(inplace=True)
        logger.info(f"✅ {asset} {timeframe}: {len(df)} candles")
        return df

    except Exception as e:
        logger.error(f"Erro ao puxar {asset} {timeframe}: {e}")
        return None


def fetch_current_price(asset: str) -> dict | None:
    """Puxa preço atual + variação do ativo."""
    symbol = SYMBOLS.get(asset)
    if not symbol:
        return None

    try:
        ticker = yf.Ticker(symbol)
        info = ticker.fast_info

        price = info.last_price
        prev_close = info.previous_close

        if not price or not prev_close:
            # fallback via history
            df = ticker.history(period='2d', interval='1d')
            if len(df) < 2:
                return None
            price = float(df['Close'].iloc[-1])
            prev_close = float(df['Close'].iloc[-2])

        change = price - prev_close
        change_pct = (change / prev_close) * 100

        return {
            'asset':      asset,
            'price':      round(price, 5),
            'change':     round(change, 5),
            'change_pct': round(change_pct, 2),
            'direction':  '⬆️' if change >= 0 else '⬇️',
        }

    except Exception as e:
        logger.error(f"Erro ao puxar preço de {asset}: {e}")
        return None


def fetch_intermarket() -> dict:
    """Puxa dados de intermarket: DXY, Yields, SP500, WTI."""
    result = {}
    assets = ['DXY', 'US10Y', 'SP500', 'WTI', 'XAUUSD', 'BTCUSD']

    for asset in assets:
        data = fetch_current_price(asset)
        if data:
            result[asset] = data

    return result


def fetch_all_assets_prices() -> dict:
    """Puxa preço atual dos 4 ativos principais."""
    result = {}
    for asset in ['XAUUSD', 'EURUSD', 'USDJPY', 'BTCUSD']:
        data = fetch_current_price(asset)
        if data:
            result[asset] = data
    return result


def fetch_multi_timeframe(asset: str) -> dict:
    """Puxa dados do ativo em todos os timeframes."""
    result = {}
    for tf in ['D1', '4H', '2H', '1H', '15M', '5M', '1M']:
        df = fetch_ohlcv(asset, tf)
        if df is not None:
            result[tf] = df
    return result
